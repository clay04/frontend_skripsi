import logo from "./logo.png"
import about from "./about.jpg"
import altFeatures from "./alt-features.png"
import heroImg from "./hero-img.png"
import favicon from "./favicon.png"
import appleTouchICon from "./apple-touch-icon.png"
import features from "./features.png"
import heroBG from "./hero-bg.png"
import Services from "./services.jpg"
import Values1 from "./values-1.png"
import Values2 from "./values-2.png"
import Values3 from "./values-3.png"
import LogoUK from "./logoUnklab.png"
import LogoUK1 from "./logoUk1.png"
import LogoGenbi from "./Logo Genbi 1.png"
import KIPLogo from "./KIP.png"
import ScholarshipLogo from "./National-Overseas-Scholarship-image.png"
import ScholarshipBanner from "./hero_banner_image_-_kuncie_scholarship_management_-_1920x900pt.png"

export{logo, about, altFeatures, heroImg, favicon, appleTouchICon, features, 
        heroBG, Services, Values1, Values2, Values3, LogoUK, LogoUK1, LogoGenbi,
        KIPLogo, ScholarshipLogo, ScholarshipBanner};