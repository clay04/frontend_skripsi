import React from "react";
import { Link } from "react-router-dom";
import "./dashboard-bidang-kemahasiswaan.css";

const DashboardBidangKemahasiswaan = () => {
    return (
        <>
            <h1>Dashboard Bidang Kemahasiswaan</h1>
        </>
    )
}

export default DashboardBidangKemahasiswaan;